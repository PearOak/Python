def gera_creds():
	dict = {}
	dict["email"] = "rpa.csc@bild.com.br"
	dict["senha"] = "KBTxCx2by.RG!wnTsngq"
	return dict
